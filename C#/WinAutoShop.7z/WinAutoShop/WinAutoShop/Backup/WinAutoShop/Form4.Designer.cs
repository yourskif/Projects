namespace WinAutoShop
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textModelAuto = new System.Windows.Forms.TextBox();
            this.textColor = new System.Windows.Forms.TextBox();
            this.textAccessories = new System.Windows.Forms.TextBox();
            this.textf4Name = new System.Windows.Forms.TextBox();
            this.textf4Code = new System.Windows.Forms.TextBox();
            this.textf4Passport = new System.Windows.Forms.TextBox();
            this.textf4Address = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(329, 439);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textModelAuto
            // 
            this.textModelAuto.Location = new System.Drawing.Point(38, 25);
            this.textModelAuto.Name = "textModelAuto";
            this.textModelAuto.Size = new System.Drawing.Size(208, 20);
            this.textModelAuto.TabIndex = 1;
            this.textModelAuto.TextChanged += new System.EventHandler(this.textModelAuto_TextChanged);
            // 
            // textColor
            // 
            this.textColor.Location = new System.Drawing.Point(38, 70);
            this.textColor.Name = "textColor";
            this.textColor.Size = new System.Drawing.Size(208, 20);
            this.textColor.TabIndex = 2;
            // 
            // textAccessories
            // 
            this.textAccessories.Location = new System.Drawing.Point(38, 122);
            this.textAccessories.Name = "textAccessories";
            this.textAccessories.Size = new System.Drawing.Size(208, 20);
            this.textAccessories.TabIndex = 3;
            this.textAccessories.TextChanged += new System.EventHandler(this.textAccessories_TextChanged);
            // 
            // textf4Name
            // 
            this.textf4Name.Location = new System.Drawing.Point(38, 171);
            this.textf4Name.Name = "textf4Name";
            this.textf4Name.Size = new System.Drawing.Size(208, 20);
            this.textf4Name.TabIndex = 4;
            // 
            // textf4Code
            // 
            this.textf4Code.Location = new System.Drawing.Point(38, 216);
            this.textf4Code.Name = "textf4Code";
            this.textf4Code.Size = new System.Drawing.Size(208, 20);
            this.textf4Code.TabIndex = 5;
            // 
            // textf4Passport
            // 
            this.textf4Passport.Location = new System.Drawing.Point(38, 258);
            this.textf4Passport.Name = "textf4Passport";
            this.textf4Passport.Size = new System.Drawing.Size(208, 20);
            this.textf4Passport.TabIndex = 6;
            // 
            // textf4Address
            // 
            this.textf4Address.Location = new System.Drawing.Point(38, 300);
            this.textf4Address.Name = "textf4Address";
            this.textf4Address.Size = new System.Drawing.Size(208, 20);
            this.textf4Address.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "ModelAuto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Color";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Accessories";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Code";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Passport";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(41, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Address";
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.button2.Location = new System.Drawing.Point(38, 439);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "submit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 475);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textf4Address);
            this.Controls.Add(this.textf4Passport);
            this.Controls.Add(this.textf4Code);
            this.Controls.Add(this.textf4Name);
            this.Controls.Add(this.textAccessories);
            this.Controls.Add(this.textColor);
            this.Controls.Add(this.textModelAuto);
            this.Controls.Add(this.button1);
            this.Name = "Report";
            this.Text = "Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textModelAuto;
        private System.Windows.Forms.TextBox textColor;
        private System.Windows.Forms.TextBox textAccessories;
        private System.Windows.Forms.TextBox textf4Name;
        private System.Windows.Forms.TextBox textf4Code;
        private System.Windows.Forms.TextBox textf4Passport;
        private System.Windows.Forms.TextBox textf4Address;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
    }
}