//using System;
//using BlackJackCard;

//namespace BlackJackComputer
//{
//    class Computer : Card
//    {
//        int sum = 0;
//        //        Player() { sum = 0; }
//        public void SetComputer(int val) { sum = sum + val; }

//        //        public int GetComputer() { return sum;}


//        public void PrintComputer()
//        {
//            Console.WriteLine("computer sum= {0}", sum);
//        }
//    }
//}
