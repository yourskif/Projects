﻿using System;

public class ProductsDetails
{
    // Общий конструктор
    public ProductsDetails(int productsID, int categoryID, string productsName,
        string productsDescription, int productsPrice)
    {
        this.productsID = productsID;
        this.categoryID = categoryID;
        this.productsName = productsName;
        this.productsDescription = productsDescription;
        this.productsPrice = productsPrice;
    }

    // Конструктор по умолчанию обязателен, 
    // если создали общий конструктор
    public ProductsDetails()
    {
    }

    // Добавляем свойства класса
    private int productsID;
    public int ProductsID
    {
        get { return productsID; }
        set { productsID = value; }
    }

    private int categoryID;
    public int CategoryID
    {
        get { return categoryID; }
        set { categoryID = value; }
    }

    private string productsName;
    public string ProductsName
    {
        get { return productsName; }
        set { productsName = value; }
    }
    private string productsDescription;
    public string ProductsDescription
    {
        get { return productsDescription; }
        set { productsDescription = value; }
    }
    private int productsPrice;
    public int ProductsPrice
    {
        get { return productsPrice; }
        set { productsPrice = value; }
    }

}

    
