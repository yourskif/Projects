﻿using System;
using System.Data;
    
using System.Data.SqlClient;
    
public partial class ProductsDB
{
    public int InsertProducts(ProductsDetails emp)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("InsertProducts", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = emp.CategoryID;

        cmd.Parameters.Add(new SqlParameter("@ProductsName", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ProductsName"].Value = emp.ProductsName;

        cmd.Parameters.Add(new SqlParameter("@ProductsDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ProductsDescription"].Value = emp.ProductsDescription;

        cmd.Parameters.Add(new SqlParameter("@ProductsPrice", SqlDbType.Int));
        cmd.Parameters["@ProductsPrice"].Value = emp.ProductsPrice;

        cmd.Parameters.Add(new SqlParameter("@ProductsID", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsID"].Direction = ParameterDirection.Output;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            return (int)cmd.Parameters["@ProductsID"].Value;
        }
        //catch
        //{
        //    throw new ApplicationException("Ошибка данныx.");
        //}
        finally
        {
            con.Close();
        }
    }


}
