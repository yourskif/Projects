﻿//ShopsDB.cs
using System;

using System.Web.Configuration;

public partial class ShopsDB
{
    private string connectionString;
    public ShopsDB()
    {
        // Извлечь из файла web.config строку соединения по умолчанию
        connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;
    }

    public ShopsDB(string connectionStringCustom)
    {
        // Извлечь из файла web.config другую строку соединения
        connectionString = WebConfigurationManager.
            ConnectionStrings[connectionStringCustom].ConnectionString;
    }
}
