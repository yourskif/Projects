﻿using System;
using System.Data;
    
using System.Data.SqlClient;
    
public partial class CategoryDB
{
    public void DeleteCategory(int categoryID)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("DeleteCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = categoryID;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        finally
        {
            con.Close();
        }
    }
}
