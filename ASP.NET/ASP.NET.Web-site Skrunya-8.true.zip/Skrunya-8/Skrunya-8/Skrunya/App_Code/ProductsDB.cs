﻿using System;
    
using System.Web.Configuration;

public partial class ProductsDB
{
    private string connectionString;
    public ProductsDB()
    {
        // Извлечь из файла web.config строку соединения по умолчанию
        connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;
    }

    public ProductsDB(string connectionStringCustom)
    {
        // Извлечь из файла web.config другую строку соединения
        connectionString = WebConfigurationManager.
            ConnectionStrings[connectionStringCustom].ConnectionString;
    }

}
