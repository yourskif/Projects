﻿//GetAllProductsDB.cs
using System;
using System.Data;

using System.Data.SqlClient;
using System.Collections.Generic;

public partial class ProductsDB
{
    public List<ProductsDetails> GetAllProducts()
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("GetAllProducts", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // Создать коллекцию для всех записей 
        List<ProductsDetails> products = new List<ProductsDetails>();

        try
        {
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ProductsDetails emp = new ProductsDetails(
                (int)reader["ProductsID"],
                (int)reader["CategoryID"],
                (string)reader["ProductsName"],
                (string)reader["ProductsDescription"],
                (int)reader["ProductsPrice"]);
                products.Add(emp);
            }
            reader.Close();
            return products;
        }
        //catch
        //{
        //    throw new ApplicationException("Ошибка данныx.");
        //}
        finally
        {
            con.Close();
        }
    }

}
