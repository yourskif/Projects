﻿//CategoryDB.cs
using System;

using System.Web.Configuration;

public partial class CategoryDB
{
    private string connectionString;
    public CategoryDB()
    {
        // Извлечь из файла web.config строку соединения по умолчанию
        connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;
    }

    public CategoryDB(string connectionStringCustom)
    {
        // Извлечь из файла web.config другую строку соединения
        connectionString = WebConfigurationManager.
            ConnectionStrings[connectionStringCustom].ConnectionString;
    }
}
