﻿//InsertShopsDB.cs
using System;
using System.Data;

using System.Data.SqlClient;

public partial class ShopsDB
{
    public int InsertShops(ShopsDetails emp)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("InsertShops", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add(new SqlParameter("@ShopsID", SqlDbType.Int, 4));
        cmd.Parameters["@ShopsID"].Value = emp.ShopsID;

        cmd.Parameters.Add(new SqlParameter("@ShopsName", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ShopsName"].Value = emp.ShopsName;
        cmd.Parameters.Add(new SqlParameter("@ShopsDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ShopsDescription"].Value = emp.ShopsDecription;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            return (int)cmd.Parameters["@ShopsID"].Value;
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        //finally
        //{
        //    con.Close();
        //}
    }

}
