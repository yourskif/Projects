﻿//GetAllCategoryDB.cs
using System;
using System.Data;

using System.Data.SqlClient;
using System.Collections.Generic;

public partial class CategoryDB
{
    public List<CategoryDetails> GetAllCategory()
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("GetAllCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // Создать коллекцию для всех записей 
        List<CategoryDetails> category = new List<CategoryDetails>();

        try
        {
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                CategoryDetails emp = new CategoryDetails(
                (int)reader["CategoryID"],
                (string)reader["CategoryName"],
                (string)reader["CategoryDescription"]);
                category.Add(emp);



            }
            reader.Close();
            return category;
        }
        //catch
        //{
        //    throw new ApplicationException("Ошибка данныx.");
        //}
        finally
        {
            con.Close();
        }
    }

}
