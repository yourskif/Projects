﻿//UpdateProductsDB.cs
using System;
using System.Data;
    
using System.Data.SqlClient;
    
public partial class ProductsDB
{
    // Исходный метод 
    public void UpdateProducts(int productsID, int categoryID, string productsName,
                               string productsDescription, int productsPrice)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("UpdateProducts", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@ProductsID", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsID"].Value = productsID;
        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = categoryID;
        cmd.Parameters.Add(new SqlParameter("@ProductsName", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ProductsName"].Value = productsName;
        cmd.Parameters.Add(new SqlParameter("@ProductsDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ProductsDescription"].Value = productsDescription;
        cmd.Parameters.Add(new SqlParameter("@ProductsPrice", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsPrice"].Value = productsPrice;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        //catch
        //{
        //    throw new ApplicationException("Ошибка данныx.");
        //}
        finally
        {
            con.Close();
        }
    }
    
    // Перегружаемый метод с объектом класса ProductsDetails
    public void UpdateProducts(ProductsDetails emp)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("UpdateProducts", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@ProductsID", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsID"].Value = emp.ProductsID;
        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = emp.CategoryID;
        cmd.Parameters.Add(new SqlParameter("@ProductsName", SqlDbType.NVarChar, 10));
        cmd.Parameters["@ProductsName"].Value = emp.ProductsName;
        cmd.Parameters.Add(new SqlParameter("@ProductsDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@ProductsDescription"].Value = emp.ProductsDescription;
        cmd.Parameters.Add(new SqlParameter("@ProductsPrice", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsPrice"].Value = emp.ProductsPrice;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        finally
        {
            con.Close();
        }
    }
    
}
