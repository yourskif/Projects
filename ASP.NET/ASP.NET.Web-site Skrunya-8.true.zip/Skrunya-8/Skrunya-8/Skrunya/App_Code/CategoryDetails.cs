﻿//CategoryDetails.cs
using System;

public class CategoryDetails
{
    // Общий конструктор
    public CategoryDetails(int categoryID, string categoryName, string categoryDescription)
    {
        this.categoryID = categoryID;
        this.categoryName = categoryName;
        this.categoryDescription = categoryDescription;
    }

    // Конструктор по умолчанию обязателен, 
    // если создали общий конструктор
    public CategoryDetails()
    {
    }

    // Добавляем свойства класса
    private int categoryID;
    public int CategoryID
    {
        get { return categoryID; }
        set { categoryID = value; }
    }

    private string categoryName;
    public string CategoryName
    {
        get { return categoryName; }
        set { categoryName = value; }
    }
    private string categoryDescription;
    public string CategoryDescription
    {
        get { return categoryDescription; }
        set { categoryDescription = value; }
    }
}

