﻿//UpdateCategoryB.cs
using System;
using System.Data;
    
using System.Data.SqlClient;
    
public partial class CategoryDB
{
    // Исходный метод 
    public void UpdateCategory(int categoryID, string categoryName,
                               string categoryDescription)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("UpdateCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = categoryID;
        cmd.Parameters.Add(new SqlParameter("@CategoryName", SqlDbType.NVarChar, 20));
        cmd.Parameters["@CategoryName"].Value = categoryName;
        cmd.Parameters.Add(new SqlParameter("@CategoryDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@CategoryDescription"].Value = categoryDescription;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        finally
        {
            con.Close();
        }
    }
    
    // Перегружаемый метод с объектом класса CategoryDetails
    public void UpdateCategory(CategoryDetails emp)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("UpdateCategory", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add(new SqlParameter("@CategoryID", SqlDbType.Int, 4));
        cmd.Parameters["@CategoryID"].Value = emp.CategoryID;

        cmd.Parameters.Add(new SqlParameter("@CategoryName", SqlDbType.NVarChar, 20));
        cmd.Parameters["@CategoryName"].Value = emp.CategoryName;

        cmd.Parameters.Add(new SqlParameter("@CategoryDescription", SqlDbType.NVarChar, 20));
        cmd.Parameters["@CategoryDescription"].Value = emp.CategoryDescription;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        finally
        {
            con.Close();
        }
    }
    
}
