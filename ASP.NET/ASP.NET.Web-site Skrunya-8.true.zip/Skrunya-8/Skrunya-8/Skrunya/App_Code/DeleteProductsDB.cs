﻿//DeleteProductsDB.cs
using System;
using System.Data;
    
using System.Data.SqlClient;
    
public partial class ProductsDB
{
    public void DeleteProducts(int productsID)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("DeleteProducts", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@ProductsID", SqlDbType.Int, 4));
        cmd.Parameters["@ProductsID"].Value = productsID;
    
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch
        {
            throw new ApplicationException("Ошибка данныx.");
        }
        finally
        {
            con.Close();
        }
    }
}
