﻿//ShopsDetails.cs
using System;

public class ShopsDetails
{
    // Общий конструктор
    public ShopsDetails(int shopsID, string shopsName, string shopsDescription)
    {
        this.shopsID = shopsID;
        this.shopsName = shopsName;
        this.shopsDescription = shopsDescription;
    }

    // Конструктор по умолчанию обязателен, 
    // если создали общий конструктор
    public ShopsDetails()
    {
    }

    // Добавляем свойства класса
    private int shopsID;
    public int ShopsID
    {
        get { return shopsID; }
        set { shopsID = value; }
    }

    private string shopsName;
    public string ShopsName
    {
        get { return shopsName; }
        set { shopsName = value; }
    }
    private string shopsDescription;
    public string ShopsDecription
    {
        get { return shopsDescription; }
        set { shopsDescription = value; }
    }
}

