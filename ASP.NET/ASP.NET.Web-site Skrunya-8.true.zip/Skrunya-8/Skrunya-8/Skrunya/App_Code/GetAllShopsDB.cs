﻿//GetAllShopsDB.cs
using System;
using System.Data;

using System.Data.SqlClient;
using System.Collections.Generic;

public partial class ShopsDB
{
    public List<ShopsDetails> GetAllShops()
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("GetAllShops", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // Создать коллекцию для всех записей 
        List<ShopsDetails> shops = new List<ShopsDetails>();

        try
        {
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ShopsDetails emp = new ShopsDetails(
                (int)reader["ShopsID"],
                (string)reader["ShopsName"],
                (string)reader["ShopsDescription"]);
                shops.Add(emp);



            }
            reader.Close();
            return shops;
        }
        //catch
        //{
        //    throw new ApplicationException("Ошибка данныx.");
        //}
        finally
        {
            con.Close();
        }
    }

}
