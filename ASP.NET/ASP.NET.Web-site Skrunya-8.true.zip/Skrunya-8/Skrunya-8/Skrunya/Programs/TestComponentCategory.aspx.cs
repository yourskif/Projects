﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class TestComponent : System.Web.UI.Page
{
    // Создать компонент базы данных
    private CategoryDB db = new CategoryDB();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblInfo.Text = "<h2>Исходная таблица</h2>";
        WriteCategoryList();

        int empID = db.InsertCategory(
            new CategoryDetails(0, "Прод", "Прод"));
        lblInfo.Text += "<h2>Вставлена 1 запись.</h2>";
        WriteCategoryList();

        //db.DeleteEmployee(empID);
        //lblInfo.Text += "<h2>Удалена 1 запись.</h2>";
        //WriteEmployeesList();
    }

    private void WriteCategoryList()
    {
        StringBuilder htmlStr = new StringBuilder("");

        List<CategoryDetails> category = db.GetAllCategory();
        foreach (CategoryDetails emp in category)
        {
            htmlStr.Append("<li>");
            htmlStr.Append(emp.CategoryID);
            htmlStr.Append(" ");
            htmlStr.Append("</b>, ");           
            htmlStr.Append(emp.CategoryName);
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.CategoryDescription);
            htmlStr.Append("</li>");
        }

        //int numEmployees = db.CountEmployees();
        //htmlStr.Append("<hr />Число записей: <b>");
        //htmlStr.Append(numEmployees.ToString());
        //htmlStr.Append("</b><br /><br />");
        //lblInfo.Text += htmlStr.ToString();
    }
}

