﻿using System;
using System.Data;

using System.Web.Configuration;
using System.Data.SqlClient;
using System.Text;

public partial class DataSetRelationShips : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Извлекаем строку соединения с именем Products из файла web.config
        string connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;

        // Создаем объект соединения
        SqlConnection con = new SqlConnection(connectionString);

        // Формируем строки SQL-запросов
        string sqlCategories = "SELECT categoryID, categoryName, categoryDescription FROM category";
        string sqlProducts = "SELECT productsName, categoryID FROM Products";

        // Создаем объект DataAdapter
        SqlDataAdapter adapter = new SqlDataAdapter(sqlCategories, con);

        // Создаем пустой объект DataSet набора данных
        DataSet dataset = new DataSet();

        // Выполняем два запроса к БД с открытием 
        // и закрытием соединения вручную.
        // Возможные исключения не обрабатываем, а просто подавляем
        try
        {
            con.Open();
            // Наполнить DataSet данными из таблицы Categories
            // с именованной меткой CatTable
            adapter.Fill(dataset, "category");
            // Сменить команду и добавить в DataSet данные
            // с именованной меткой ProdTable из таблицы Products
            adapter.SelectCommand.CommandText = sqlProducts;
            adapter.Fill(dataset, "products");
        }
        finally
        {
            con.Close();
        }

        // Определение отношения между  извлеченными в DataSet
        // именованными данными CategoryTable и ProductionTable
        DataRelation relation = new DataRelation(
            "CategoryProduction",                                          // Имя отношения
            dataset.Tables["category"].Columns["categoryID"],   // Родительская таблица
            dataset.Tables["products"].Columns["categoryID"]   // Дочерняя таблица
                                                    );
        // Добавление отношения в коллекцию отношений DataSet
        dataset.Relations.Add(relation);

        // Перебираем все извлеченные категории продуктов
        // и для каждой из них собираем сопоставленные продукты
        StringBuilder htmlStr = new StringBuilder("");
        foreach (DataRow row in dataset.Tables["category"].Rows)
        {
            htmlStr.Append("<b>");
            htmlStr.Append(row["categoryName"].ToString());         // Имя поля
            htmlStr.Append("</b>");

            // Собираем дочерние записи из products для 
            // текущего значения родителя category в массив
            DataRow[] childRows = row.GetChildRows(relation);
            htmlStr.Append("<ul>"); // Открыли маркированный список HTML
            foreach (DataRow childRow in childRows)
            {
                htmlStr.Append("<li>"); // Элемент маркированного списка HTML
                htmlStr.Append(childRow["productsName"].ToString());  // Имя поля
                htmlStr.Append("</li>");
            }
            htmlStr.Append("</ul>"); // Закрыли маркированный список HTML
        }

        // Отображаем полученные данные ненавистному пользователю
        lblInfo.Text = htmlStr.ToString();
    }
}
