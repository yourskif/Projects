﻿using System;
using System.Data;

using System.Web.Configuration;
using System.Data.SqlClient;

public partial class GridViewcategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Содать Connection, DataAdapter и DataSet
        string connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        string sql =
            "SELECT TOP 5 categoryID, categoryName, "
          + "categoryDescription FROM Category";
        SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
        DataSet dataset = new DataSet();
        adapter.Fill(dataset, "CategoryTable");

        // Привязать данные к GridView1 для отображения
        GridView1.DataSource = dataset;
        GridView1.DataMember = "CategoryTable";
        GridView1.DataBind();
    }
}
