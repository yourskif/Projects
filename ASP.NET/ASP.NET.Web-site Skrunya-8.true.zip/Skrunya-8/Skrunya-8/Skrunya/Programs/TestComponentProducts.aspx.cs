﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class TestComponent : System.Web.UI.Page
{
    // Создать компонент базы данных
    //    private EmployeeDB db = new EmployeeDB();
    private ProductsDB db = new ProductsDB();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblInfo.Text = "<h2>Исходная таблица</h2>";
        //WriteEmployeesList();
        WriteProductsList();

        int empID = db.InsertProducts(new ProductsDetails(0, 1, "Хліб","Карпатский",5));
        lblInfo.Text += "<h2>Вставлена 1 запись.</h2>";
        WriteProductsList();

        //db.DeleteEmployee(empID);
        //lblInfo.Text += "<h2>Удалена 1 запись.</h2>";
        //WriteEmployeesList();
    }

    private void WriteProductsList()
    {
        StringBuilder htmlStr = new StringBuilder("");

        List<ProductsDetails> products = db.GetAllProducts();
        foreach (ProductsDetails emp in products)
        {
            htmlStr.Append("<li>");
            htmlStr.Append(emp.ProductsID);
            htmlStr.Append(" ");
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.CategoryID);
            htmlStr.Append(" ");
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.ProductsName);
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.ProductsDescription);
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.ProductsPrice);
            htmlStr.Append("</b>, ");
            htmlStr.Append("</li>");

        }

        //int numEmployees = db.CountEmployees();
        //htmlStr.Append("<hr />Число записей: <b>");
        //htmlStr.Append(numEmployees.ToString());
        //htmlStr.Append("</b><br /><br />");
        //lblInfo.Text += htmlStr.ToString();
    }
}

