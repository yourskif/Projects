﻿using System;
using System.Data;
    
using System.Web.Configuration;
using System.Data.SqlClient;
    
public partial class GridViewDataView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Содать Connection, DataAdapter и DataSet
        string connectionString = WebConfigurationManager.
            ConnectionStrings["Northwind"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        string sql = 
            "SELECT TOP 5 EmployeeID, TitleOfCourtesy, LastName, "
          + "FirstName FROM Employees";
        SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
        DataSet dataset = new DataSet();
        adapter.Fill(dataset, "EmployeesTable");
    
        // Привязать данные к GridView1 для отображения
        // без сортировки как они есть
        GridView1.DataSource = dataset.Tables["EmployeesTable"];
    
        // Скопировать данные в экземпляр класса DataView,
        // отсортировать по полю FirstName, затем привязать
        DataView view2 = new DataView(dataset.Tables["EmployeesTable"]);
        view2.Sort = "FirstName";
        GridView2.DataSource = view2;
    
        // Скопировать данные в экземпляр класса DataView,
        // отсортировать по полю FirstName, затем привязать
        DataView view3 = new DataView(dataset.Tables["EmployeesTable"]);
        view3.Sort = "LastName";
        GridView3.DataSource = view3;
    
        // Загрузить привязанные данные во все элементы отображения GridView
        Page.DataBind();
    }
}
