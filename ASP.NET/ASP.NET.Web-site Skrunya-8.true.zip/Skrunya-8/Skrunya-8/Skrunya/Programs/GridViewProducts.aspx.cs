﻿//GridViewProducts.aspx.cs
using System;
using System.Data;

using System.Web.Configuration;
using System.Data.SqlClient;

public partial class GridViewProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Содать Connection, DataAdapter и DataSet
        string connectionString = WebConfigurationManager.
            ConnectionStrings["ProductsFirm"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);
        string sql =
            "SELECT TOP 5 productsID, productsName, "
          + "productsDescription, productsPrice FROM products";
        SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
        DataSet dataset = new DataSet();
        adapter.Fill(dataset, "ProductsTable");

        // Привязать данные к GridView1 для отображения
        GridView1.DataSource = dataset;
        GridView1.DataMember = "ProductsTable";
        GridView1.DataBind();
    }
}
