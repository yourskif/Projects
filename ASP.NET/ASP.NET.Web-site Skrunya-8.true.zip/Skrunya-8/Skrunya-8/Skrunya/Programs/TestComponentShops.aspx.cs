﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class TestComponent : System.Web.UI.Page
{
    // Создать компонент базы данных
    private ShopsDB db = new ShopsDB();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblInfo.Text = "<h2>Исходная таблица</h2>";
        //WriteEmployeesList();
        WriteShopsList();

        int empID = db.InsertShops(
            new ShopsDetails(0, "Маг", "Маг"));
        lblInfo.Text += "<h2>Вставлена 1 запись.</h2>";
        WriteShopsList();

        //db.DeleteEmployee(empID);
        //lblInfo.Text += "<h2>Удалена 1 запись.</h2>";
        //WriteEmployeesList();
    }

    private void WriteShopsList()
    {
        StringBuilder htmlStr = new StringBuilder("");

        List<ShopsDetails> shops = db.GetAllShops();
        foreach (ShopsDetails emp in shops)
        {
            htmlStr.Append("<li>");
            htmlStr.Append(emp.ShopsID);
            htmlStr.Append(" ");
            htmlStr.Append("</b>, ");           
            htmlStr.Append(emp.ShopsName);
            htmlStr.Append("</b>, ");
            htmlStr.Append(emp.ShopsDecription);
            htmlStr.Append("</li>");
        }

        //int numEmployees = db.CountEmployees();
        //htmlStr.Append("<hr />Число записей: <b>");
        //htmlStr.Append(numEmployees.ToString());
        //htmlStr.Append("</b><br /><br />");
        //lblInfo.Text += htmlStr.ToString();
    }
}

